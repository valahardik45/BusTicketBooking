<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" type="text/css" href="sleeper_style.css" />
<title>Untitled Document</title>
</head>

<body>
<?php
include("main.php");
?>
<form method="post">
<div class="ac">
<div class="label">
 Select Bus
 </div>
<table border="2" style="height:120px; width:100px; font-size:20px;">
<tr><td>
Number</td></tr>
<tr><td>
info</td></tr>
<tr><td>
book</td></tr>
</table>
</div>

</form>
</body>
</html>
