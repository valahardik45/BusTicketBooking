<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link rel="stylesheet" type="text/css" href="admin_data_style.css" />
</head>

<body background="bg.jpg">
<form method="post">
<center>
<a href="addr.php"><input type="button" value="Add Data" name="add" class="btn" /></a>
<a href="editdt.php"><input type="button" value="Edit Data" name="delete" class="btn"  /></a>
<a href="deletedt.php"><input type="button" value="Delete Data" name="delete" class="btn"  /></a>
<input type="button" value="View Booking" name="td" class="btn" /><br />
<a href="admin.php"><button type="button" name="cmdback" class="lbtn" style="cursor:pointer">Logout</button></a>

</center>
</form>
</body>
</html>