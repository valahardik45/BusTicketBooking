<html> 

<SCRIPT language="JavaScript"> 

var q1=Math.floor(Math.random()*11) 
<?php 
$ff =  q1; 
?> 

 } 

</SCRIPT> 

</HEAD> 

<BODY> 
<?php 
echo $ff ; 
?> 
</body> 
</html>