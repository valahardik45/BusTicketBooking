<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link rel="stylesheet" type="text/css" href="main_style.css" />
</head>

<body>
</div>
<div class="header2"><h4>
<a href="dest.php"><input type="button" name="cmdhome" value="Home" class="b1 b2"></a>
<a href="cust_sup.php"><input type="button" name="cmdcust" value="Customer Support" class="b1 b2"></a> 
<a href="print_ticket.php"><input type="button" name="cmdprint" value="Print Ticket" class="b1 b2"></a>
<a href="cancle_ticket.php"><input type="button" name="cmdhome" value="Cancle Ticket" class="b1 b2"></a>
<a href="login.php"><input type="submit" name="cmdlogin" value="Login" class="c1 c2" />
</a>

</h4></div>
</body>
</html>