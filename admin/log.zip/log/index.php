<?php	
session_start();
if(isset($_POST['login']))
{
	$con=mysqli_connect("localhost","root","","bus")or die("connection not found").mysql_error();
	//$db=mysqli_select_db("bus")or die("database not found").mysql_error();
	if(isset($_POST["login"]))
	{
		$user=$_POST['user'];
		$pwd1=$_POST['pwd1'];
		$_SESSION["usrnm"] = $user;
		$sql="SELECT * FROM bus.user WHERE u_user='".$user."'AND u_pwd1='".$pwd1."'";
		$res=mysqli_query($con,$sql);
		if(mysqli_num_rows($res)>0)
		{
			$_SESSION["hardik"]="$user";
			echo"<script>alert('You Are SuccessFuly Login')</script>";
			header("location:selectj.php");
		}
		else
		{
			echo"<script>alert('Enter Valid Username and Password');</script>";
		}
	}
	
}
/*function mb_send_mail(*/
?>
<!DOCTYPE>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>login</title>
<link rel="stylesheet" type="text/css" href="login_style.css">
<link rel ="stylesheet" type="text/css" href="slider.css">
</head>
<script type="text/javascript">
window.history.forward();
	function noBack()
	{
		window.history.forward();
	}
</script>
<body onLoad="noBack();" onpageshow="if(event.persisted) noBack();"onUnload=""> 
<div class='header1'>
Star Bus Ticket Booking
</div> 
<div class="header">
		<h2>Login</h2>
	</div>
	<form method="post">
		<div class="input-group">
			<input type="text"  name="user" placeholder= "Enter your username" required>
		</div>
		<div class="input-group">
			<input type="password" name="pwd1" placeholder="Enter Your Password" required>
		</div>
       	<center><input type="submit" name="login" value="Login" class="btn"/> </button></center></div>
        <center><a href="forget.php">Forget Password?</a></center>
		<center>New User? <a href="register.php">Sign up</a></center>
	</form>
</body>
</html>

