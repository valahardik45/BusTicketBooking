<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>main</title>

</head>
<body>

			
<select name="opt">
<option value="Rajkot">Rajkot</option>
<option value="Ahemdabad">Ahemdabad</option>
<option value="Surat">Surat</option>
<option value="Baroda">Baroda</option>
<option value="Gondal">Gondal</option>
<option value="Jamnagar">Jamnagar</option>
<option value="Diu">Diu</option>
<option value="Junagadh">Junagadh</option>
<option value="Bhavnagar">Bhavnagar</option>
</option>

</body>

</html>

