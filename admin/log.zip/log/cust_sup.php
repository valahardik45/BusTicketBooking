<?php
include("main.php");
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link rel="stylesheet" type="text/css" href="cust_sup.css">
</head>
<body>
<form method="post">
<div class="a">
<center>
 This Website
</center>
</div>

<div class="b">
<center> <label class="l"><h3> Contacts Us </h3></label>
<table align="center">
<tr><td><h5>Ahemdabad Branch:</td>
<td><h5>&nbsp;&nbsp;&nbsp;09685742300</td></tr>
<tr><td><h5>Rajkot Branch:</td>
<td><h5>&nbsp;&nbsp;&nbsp;09685742301</td></tr>
<tr><td><h5>Baroda Branch:</td>
<td><h5>&nbsp;&nbsp;&nbsp;09685742302</td></tr>
</table>
</center>
</div>


	
</form>	
</body>
</html>
