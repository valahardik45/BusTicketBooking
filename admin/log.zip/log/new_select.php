<?php
include("main.php");
if(isset($_POST["cmdbook"])){
	$con=mysqli_connect("localhost","root","","bus") or die("connection not found").mysql_error();
	$seats = $_POST["selectedSeats"];
	$selseats = substr($seats,strpos($seats,">")+1);
	$selseats = trim($selseats);
	$cost = 0;
	$noseats = 0;
	if(strlen($selseats)>3){
		$cost = 800;
		$noseats = 2;
	}
	else{
		$cost = 400;
		$noseats = 1;
	}
	$username = $_SESSION["usrnm"];
	$busid=$_SESSION['bsid'];
	$query = "insert into tickbook(u_name, bus_id, seat_no, tot_seat, amount) values ('".$username."', ".$busid.", '".$selseats."', ".$noseats.", ".$cost.")";
	mysqli_query($con,$query);
}
else{

$con=mysqli_connect("localhost","root","","bus") or die("connection not found").mysql_error();
//$db=mysql_select_db("bus")or die("database not found").mysql_error();
$a=$_SESSION["start"];
$b=$_SESSION["end"];
$c=$_SESSION["volvo"];
$d=$_SESSION["date"];
$id=$_GET['id'];
$_SESSION['bsid'] = $id;
$uk=mysqli_query($con,"select * from bus.schedule where id='$id'");
while($res=mysqli_fetch_array($uk))
{
$src=$res['source'];
$dest=$res['dest'];
$start=$res['dep_time'];
$end=$res['arri_time'];
$type=$res['type'];
$price=$res['price'];
echo $src;

?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>select seat</title>
<link rel="stylesheet" type="text/css" href="select_style.css" />
<!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>-->
<script type="text/javascript" src="jquery_min.js"></script>
<style>
	.selected{
		background-color:red !important;
	}
</style>
<script>
$(document).ready(function(){
	var count = 0;
	$(".btn").on("click",function(){
		var valu = this.value;
		var mul=this.value;
		
		if(count<2){
			
			if($(this).attr("class")=="btn selected"){
				$(this).removeClass("selected");
				var str = $("#selectedSeat").text();
				str = str.replace(valu,'');
				$("#selectedSeat").html(str);
				$("#selectedSeats").val(str);
				count--;
			}
			else if($(this).attr("class")=="btn"){
				$(this).addClass("selected");
				var str = $("#selectedSeat").text() + this.value +"  ";
				$("#selectedSeat").html(str);
				$("#selectedSeats").val(str);
				count++;
			}
		}
		else if($(this).attr("class")=="btn selected"){
			$(this).removeClass("selected");
			var str = $("#selectedSeat").text();
			str = str.replace(valu,'');
			$("#selectedSeat").html(str);
			$("#selectedSeats").val(str);
			count--;
		}
	});
});
</script>
</head>
<body>
<form method="post">
<div class="a">
<?php
echo "<div class='label'>" .$a."&nbsp;to&nbsp;" .$b. "&nbsp;on&nbsp;" .$d."</div>";
echo  $c."&nbsp;Bus" ;
?>
<table class="table">
<tr>
<td><input type="button" value="1"  class="btn" id="btn1"  /></td>
<td><input type="button" value="2"  class="btn" id="btn2"  /></td>
<td>&nbsp; </td>
<td><input type="button" value="3"  class="btn" id="btn3"  /></td>
<td><input type="button" value="4"  class="btn" id="btn4"  /></td>
</tr>
<tr>
<td><input type="button" value="5"  class="btn" id="btnn5"  /></td>
<td><input type="button" value="6"  class="btn" id="btn6"  /></td>
<td>&nbsp; </td>
<td><input type="button" value="7"  class="btn" id="btn7"  /></td>
<td><input type="button" value="8"  class="btn" id="btn8"  /></td>
</tr>
<tr>
<td><input type="button" value="9"  class="btn" id="btn9"  /></td>
<td><input type="button" value="10"  class="btn" id="btn10"  /></td>
<td>&nbsp; </td>
<td><input type="button" value="11"  class="btn" id="btn11"  /></td>
<td><input type="button" value="12"  class="btn" id="btn12"  /></td>
<!--<td id="selectedSeat"><center> selected seat==> </td>-->
<td>&nbsp; </td>
</tr>
<tr>
<td><input type="button" value="13"  class="btn" id="btn13"  /></td>
<td><input type="button" value="14"  class="btn" id="btn14"  /></td>
<td>&nbsp; </td>
<td><input type="button" value="15"  class="btn" id="btn15"  /></td>
<td><input type="button" value="16"  class="btn" id="btn16"  /></td>
</tr>
<tr>
<td><input type="button" value="17"  class="btn" id="btn17"  /></td>
<td><input type="button" value="18"  class="btn" id="btn18"  /></td>
<td>&nbsp; </td>
<td><input type="button" value="19"  class="btn" id="btn19"  /></td>
<td><input type="button" value="20"  class="btn" id="btn20"  /></td>
</tr>
<tr>
<td><input type="button" value="21"  class="btn" id="btn21"  /></td>
<td><input type="button" value="22"  class="btn" id="btn22"  /></td>
<td>&nbsp; </td>
<td><input type="button" value="23"  class="btn" id="btn23"  /></td>
<td><input type="button" value="24"  class="btn" id="btn24"  /></td>
</tr>
<tr>
<td><input type="button" value="25"  class="btn" id="btn25"  /></td>
<td><input type="button" value="26"  class="btn" id="btn26"  /></td>
<td>&nbsp; </td>
<td><input type="button" value="27"  class="btn" id="btn27"  /></td>
<td><input type="button" value="28"  class="btn" id="btn28"  /></td>
</tr>
<tr>
<td><input type="button" value="29"  class="btn" id="btn29"  /></td>
<td><input type="button" value="30"  class="btn" id="btn30"  /></td>
<td>&nbsp; </td>
<td><input type="button" value="31"  class="btn" id="btn31"  /></td>
<td><input type="button" value="32"  class="btn" id="btn32"  /></td>
</tr>
<tr>
<td><input type="button" value="33"  class="btn" id="btn33"  /></td>
<td><input type="button" value="34"  class="btn" id="btn34"  /></td>
<td>&nbsp; </td>
<td><input type="button" value="35"  class="btn" id="btn35"  /></td>
<td><input type="button" value="36"  class="btn" id="btn36"  /></td>
</tr>
<tr>
<td><input type="button" value="37"  class="btn" id="btn37"  /></td>
<td><input type="button" value="38"  class="btn" id="btn38"  /></td>
<td>&nbsp; </td>
<td><input type="button" value="39"  class="btn" id="btn39"  /></td>
<td><input type="button" value="40"  class="btn" id="btn40"  /></td>
</tr>
<tr>
<td><input type="button" value="41"  class="btn" id="btn41"  /></td>
<td><input type="button" value="42"  class="btn" id="btn42"  /></td>
<td>&nbsp; </td>
<td><input type="button" value="43"  class="btn" id="btn43"  /></td>
<td><input type="button" value="44"  class="btn" id="btn44"  /></td>
</tr>
<tr>
<td><input type="button" value="45"  class="btn" id="btn45"  /></td>
<td><input type="button" value="46"  class="btn" id="btn46"  /></td>
<td>&nbsp; </td>
<td><input type="button" value="47"  class="btn" id="btn47"  /></td>
<td><input type="button" value="48"  class="btn" id="btn48"  /></td>
</tr>
<tr>
<td><input type="button" value="49"  class="btn" id="btn49"  /></td>
<td><input type="button" value="50"  class="btn" id="btn50"  /></td>
<td><input type="button" value="51"  class="btn" id="btn51"  /></td>
<td><input type="button" value="52"  class="btn" id="btn52"  /></td>
<td><input type="button" value="53"  class="btn" id="btn53"  /></td>
</tr>
</table>
<label class="lbl" name="selectedSeat" id="selectedSeat">Selected Seat==></label>&nbsp;
<input type="hidden" name="selectedSeats" id="selectedSeats" />
<br/>
<?php echo $price ?>
<input type="submit" value="book" name="cmdbook" class="log" />
<a href="reguler.php"><input type="button" value="Cancel" name="cmdcancel" class="log" /></a>
</form>

 
</body>
</html>
<?php
} }
?>
