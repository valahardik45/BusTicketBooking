<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" type="text/css" href="book_style.css">
<title>Untitled Document</title>
</head>
<?php
include("main.php");
$e=$_SESSION["selectedSeat"];
echo $e;
?>
<body>
<body> 
<div class="header">
		<h2>booking details</h2>
	</div>
	<form method="post">
	
		<div class="input-group">
		<input type="text"  name="user" placeholder= "Enter Passenger Name" required>
		</div>
		
		<div class="input-group">
		<input type="text" name="pwd1" 
        placeholder="Enter Mobile Number" required>
		</div>
		
		<div class="input-group">
		<input type="text" name="pwd1" 
        placeholder="Enter Email ID (Optional)" >
		</div>
		
		
       	<center><input type="submit" name="cmdbook" 
        value="Book" class="btn"/> </button></div>
		</center>
        
        
        
        
		
			
	</form>


</body>
</html>
