-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 11, 2017 at 08:10 PM
-- Server version: 10.1.26-MariaDB
-- PHP Version: 7.0.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bus`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `a_id` int(10) NOT NULL,
  `a_user` varchar(25) NOT NULL,
  `a_pwd` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`a_id`, `a_user`, `a_pwd`) VALUES
(1, 'hardik', 'hardik123'),
(2, 'nilesh', 'nilesh123');

-- --------------------------------------------------------

--
-- Table structure for table `busdetails`
--

CREATE TABLE `busdetails` (
  `b_id` varchar(10) NOT NULL,
  `b_name` varchar(25) NOT NULL,
  `b_regno` int(10) NOT NULL,
  `b_type` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `contactus`
--

CREATE TABLE `contactus` (
  `c_id` int(10) NOT NULL,
  `c_email` varchar(25) NOT NULL,
  `c_msg` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `schedule`
--

CREATE TABLE `schedule` (
  `id` int(20) NOT NULL,
  `busno` int(20) NOT NULL,
  `dest` varchar(25) NOT NULL,
  `source` varchar(25) NOT NULL,
  `dist` varchar(10) NOT NULL,
  `dep_time` varchar(20) NOT NULL,
  `arri_time` varchar(20) NOT NULL,
  `type` varchar(20) NOT NULL,
  `price` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `schedule`
--

INSERT INTO `schedule` (`id`, `busno`, `dest`, `source`, `dist`, `dep_time`, `arri_time`, `type`, `price`) VALUES
(1, 2224, 'Ahemdabad', 'Rajkot', '220 km', '4:00 AM', '7:30 AM', 'reguler', 'Rs.400'),
(2, 2224, 'Ahemdabad', 'Rajkot', '220 km', '1:00 PM', '4:30 PM', 'reguler', 'Rs.450'),
(3, 2224, 'Ahemdabad', 'Rajkot', '220 km', '10:00 PM', '1:30 PM', 'reguler', 'Rs.400'),
(4, 2224, 'Rajkot', 'Ahemdabad', '220 km', '8:30 AM', '12:00 PM', 'reguler', 'Rs.400'),
(5, 2224, 'Rajkot', 'Ahemdabad', '220 km', '5:30 PM', '9:00 PM', 'reguler', 'Rs.450'),
(6, 2224, 'Rajkot', 'Ahemdabad', '220 km', '2:30 AM', '5:30 AM', 'reguler', 'Rs. 500'),
(7, 3122, 'Ahemdabad', 'Rajkot', '220 km', '4:00 AM', '7:30 AM', 'sleeper', 'Rs. 750'),
(8, 3122, 'Ahemdabad', 'Rajkot', '220 km', '1:00 PM', '4:30 PM', 'sleeper', 'Rs. 900'),
(9, 3122, 'Rajkot', 'Ahemdabad', '220 km', '8:30 AM', '12:00 PM', 'sleeper', 'Rs. 750'),
(10, 3122, 'Rajkot', 'Ahemdabad', '220 km', '5:30 PM', '9:00 PM', 'sleeper', 'Rs. 900'),
(11, 3484, 'Baroda', 'Ahemdabad', '111 Km', '5:00 AM', '7:00 AM', 'reguler', 'Rs. 200'),
(12, 3484, 'Baroda', 'Ahemdabad', '111 Km', '11:00 AM', '1:00 PM', 'reguler', 'Rs. 200'),
(13, 3484, 'Baroda', 'Ahemdabad', '111 Km', '5:00 PM', '7:00 PM', 'reguler', 'Rs. 250'),
(14, 3484, 'Baroda', 'Ahemdabad', '111 Km', '11:00 PM', '1:00 AM', 'reguler', 'Rs. 250'),
(15, 3484, 'Ahemdabad', 'Baroda', '111 Km', '8:00 AM', '10:00 AM', 'reguler', 'Rs. 200'),
(16, 3484, 'Ahemdabad', 'Baroda', '111 Km', '2:00 PM', '4:00 PM', 'reguler', 'Rs. 250'),
(17, 3484, 'Ahemdabad', 'Baroda', '111 Km', '8:00 PM', '10:00 PM', 'reguler', 'Rs. 250'),
(18, 3484, 'Ahemdabad', 'Baroda', '111 Km', '2:00 AM', '4:00 AM', 'reguler', 'Rs. 250'),
(19, 6135, 'Baroda', 'Rajkot', '289 Km', '4:00 AM', '10:30 AM', 'reguler', 'Rs. 1200'),
(20, 6135, 'Rajkot', 'Baroda', '289 Km', '11:30 AM', '6:00 PM', 'reguler', 'Rs. 1200'),
(21, 8836, 'Baroda', 'Rajkot', '289 Km', '5:00 AM', '11:30 AM', 'sleeper', 'Rs. 1400'),
(22, 8836, 'Rajkot', 'Baroda', '289 Km', '12:30 PM', '7:00 PM', 'sleeper', 'Rs. 1400');

-- --------------------------------------------------------

--
-- Table structure for table `tickbook`
--

CREATE TABLE `tickbook` (
  `u_name` varchar(25) NOT NULL,
  `bus_id` int(10) NOT NULL,
  `tic_id` int(10) NOT NULL,
  `seat_no` varchar(25) NOT NULL,
  `tot_seat` int(10) NOT NULL,
  `avil_seat` int(10) NOT NULL,
  `amount` int(10) NOT NULL,
  `tocken_no` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tickbook`
--

INSERT INTO `tickbook` (`u_name`, `bus_id`, `tic_id`, `seat_no`, `tot_seat`, `avil_seat`, `amount`, `tocken_no`) VALUES
('hardik99', 2, 0, '35  36', 2, 0, 800, 0);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `u_id` int(25) NOT NULL,
  `u_user` varchar(25) NOT NULL,
  `u_name` varchar(40) NOT NULL,
  `u_pwd1` varchar(20) NOT NULL,
  `u_place` varchar(25) NOT NULL,
  `u_mobile` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`u_id`, `u_user`, `u_name`, `u_pwd1`, `u_place`, `u_mobile`) VALUES
(1, 'hardik99', 'hardik', '123456', 'rajkot', 8460995145),
(2, 'rahul', 'rahul vala', '0000', 'goa', 1179070790);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`a_id`);

--
-- Indexes for table `schedule`
--
ALTER TABLE `schedule`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tickbook`
--
ALTER TABLE `tickbook`
  ADD UNIQUE KEY `bus_id` (`bus_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`u_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `a_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `schedule`
--
ALTER TABLE `schedule`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `u_id` int(25) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
